#define _CRT_SECURE_NO_WARNINGS

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"mapa.h"

#define ROZMIAR_NAZW 32
#define ROZMIAR_BUFORA 128
#define POMOC "Program sluzy do obliczania najkrotszych tras miedzy wskazanymi miastami.\nPo rzelaczniku -d nalezy podac nazwe pliku ze spisem drog.\nPo przelaczniku -t nalezy podac plik z trasami do wyznaczenia.\nPo przelaczniku -o nalezy podac nazwe pliku wyjsciowego.\n"

#define NDEBUG

// odczytywanie parametrow

int odczytaj_parametry(int ile_parametrow, char* parametry[], char plik_wyjscie[], char plik_drogi[], char plik_trasy[])
{
	const char ETYKIETA_DROGI[] = "-d";
	const char ETYKIETA_TRASY[] = "-t";
	const char ETYKIETA_WYJSCIE[] = "-o";
	const char ETYKIETA_POMOC[] = "-h";

	const int FLAGA_DROGI = 1;
	const int FLAGA_TRASY = FLAGA_DROGI << 1;
	const int FLAGA_WYJSCIE = FLAGA_TRASY << 1;

	const int wynik_poprawny = FLAGA_DROGI | FLAGA_TRASY | FLAGA_WYJSCIE;

	int wynik_sprawdzania = PROGRAM_NIE;

	int porownaj;

	for (int i = 1; i < ile_parametrow; ++i)
	{
		porownaj = strcmp(parametry[i], ETYKIETA_WYJSCIE);

		if (!porownaj)
		{
			if (!parametry[i + 1])
			{
				wynik_sprawdzania = PROGRAM_NIE;
				break;
			}

			strncpy(plik_wyjscie, parametry[i + 1], strlen(parametry[i + 1]) + 1);
			wynik_sprawdzania |= FLAGA_WYJSCIE;
		}
		else if (porownaj > 0)
		{
			porownaj = strcmp(parametry[i], ETYKIETA_TRASY);

			if (!porownaj)
			{
				if (!parametry[i + 1])
				{
					wynik_sprawdzania = PROGRAM_NIE;
					break;
				}
				strncpy(plik_trasy, parametry[i + 1], strlen(parametry[i + 1]) + 1);
				wynik_sprawdzania |= FLAGA_TRASY;
			}
		}
		else if (porownaj < 0)
		{
			porownaj = strcmp(parametry[i], ETYKIETA_DROGI);

			if (!porownaj)
			{
				if (!parametry[i + 1])
				{
					wynik_sprawdzania = PROGRAM_NIE;
					break;
				}

				strncpy(plik_drogi, parametry[i + 1], strlen(parametry[i + 1]) + 1);
				wynik_sprawdzania |= FLAGA_DROGI;
			}
			else if (porownaj > 0)
			{
				porownaj = strcmp(parametry[i], ETYKIETA_POMOC);

				if (!porownaj)
				{
					wynik_sprawdzania = PROGRAM_POMOC;
					break;
				}
			}
		}
	}

	if (wynik_sprawdzania == wynik_poprawny)
		wynik_sprawdzania = PROGRAM_OK;

	return wynik_sprawdzania;
}

// pomocnicza funkcja usprawniajaca dodawanie do listy odczytanych drog

lista_drogi* dodaj_do_listy_drog(lista_drogi* ogon, char* dane)
{
	if (!ogon)
		ogon = (lista_drogi*)malloc(sizeof(lista_drogi));
	else
		return ogon;

	ogon->skad = (char*)malloc(ROZMIAR_NAZW);
	ogon->dokad = (char*)malloc(ROZMIAR_NAZW);

	char* bufor;

	bufor = strtok(dane, "; ");
	strncpy(ogon->skad, bufor, strlen(bufor) + 1);

	bufor = strtok(NULL, "; ");
	strncpy(ogon->dokad, bufor, strlen(bufor) + 1);

	bufor = strtok(NULL, "; ");

	int ile;
	ile = atoi(bufor);

	if (!ile)
		return NULL;

	ogon->dystans = ile;
	ogon->nastepny = NULL;

	return ogon;
}

// pomocnicza funkcja usprawniajaca dodawanie do listy odczytanych tras

lista_trasy* dodaj_do_listy_tras(lista_trasy* ogon, char* dane)
{
	if (!ogon)
		ogon = (lista_trasy*)malloc(sizeof(lista_trasy));
	else
		return ogon;

	ogon->skad = (char*)malloc(ROZMIAR_NAZW);
	ogon->dokad = (char*)malloc(ROZMIAR_NAZW);

	char* bufor;

	bufor = strtok(dane, "; ");
	strncpy(ogon->skad, bufor, strlen(bufor) + 1);

	bufor = strtok(NULL, "; ");
	strncpy(ogon->dokad, bufor, strlen(bufor) + 1);

	ogon->nastepny = NULL;

	return ogon;
}

// funkcja kasujaca liste tras

void skasuj_drogi(lista_drogi* glowa)
{
	lista_drogi* smiec;

	smiec = glowa;
	glowa = glowa->nastepny;

	while (smiec)
	{
		free(smiec->dokad);
		free(smiec->skad);
		free(smiec);

		smiec->dokad = NULL;
		smiec->skad = NULL;
		smiec = glowa;

		if (glowa)
			glowa = glowa->nastepny;
	}

	//return glowa;
}

// funkcja kasujaca liste drog

void skasuj_trasy(lista_trasy* glowa)
{
	lista_trasy* smiec;

	smiec = glowa;
	glowa = glowa->nastepny;

	while (smiec)
	{
		free(smiec->dokad);
		free(smiec->skad);
		free(smiec);

		smiec->dokad = NULL;
		smiec->skad = NULL;
		smiec = glowa;

		if (glowa)
			glowa = glowa->nastepny;
	}

	//return glowa;
}

// funkcja kasujaca graf

void skasuj_graf(graf* graf_caly)
{
	graf_skad* graf_glowa;
	graf_skad* smiec_skad;
	graf_dokad* smiec_dokad;
	graf_dokad* dokad_glowa;

	smiec_skad = graf_caly->graf_glowa;
	smiec_dokad = smiec_skad->dokad;

	graf_glowa = smiec_skad->nastepny;
	dokad_glowa = smiec_dokad->nastepny;

	while (smiec_skad)
	{
		while (smiec_dokad)
		{
			free(smiec_dokad->cel);
			free(smiec_dokad);

			smiec_dokad->cel = NULL;
			smiec_dokad = dokad_glowa;

			if (smiec_dokad)
				dokad_glowa = dokad_glowa->nastepny;
		}

		free(smiec_skad->skad);
		free(smiec_skad);

		smiec_skad->skad = NULL;
		smiec_skad = graf_glowa;

		if (smiec_skad)
		{
			smiec_dokad = smiec_skad->dokad;
			graf_glowa = graf_glowa->nastepny;
		}

	}
}

// odczytwanie plikow

int odczytaj_pliki(char plik_drogi[], char plik_trasy[], lista_drogi** glowa_drogi, lista_trasy** glowa_trasy)
{
	FILE* wejscie;

	wejscie = fopen(plik_drogi, "r");

	if (!wejscie)
	{
		if (plik_drogi[strlen(plik_drogi) - 4] == '.')
		{
			plik_drogi[strlen(plik_drogi) - 3] = 't';
			plik_drogi[strlen(plik_drogi) - 2] = 'x';
			plik_drogi[strlen(plik_drogi) - 1] = 't';
		}
		else
			strcat(plik_drogi, ".txt");

		wejscie = fopen(plik_drogi, "r");

		if (!wejscie)
		{
			printf("Plik z odleglosciami nie zostal otwarty!\n");
			return PROGRAM_NIE;
		}
	}

	char bufor[ROZMIAR_BUFORA];

	lista_drogi* ogon_drogi;

	while (!feof(wejscie))
	{
		fgets(bufor, ROZMIAR_BUFORA, wejscie);

		if (!(*glowa_drogi))
		{
			*glowa_drogi = dodaj_do_listy_drog(*glowa_drogi, bufor);

			if (!*glowa_drogi)
				return PROGRAM_NIE;

			ogon_drogi = *glowa_drogi;
		}
		else
		{
			ogon_drogi->nastepny = dodaj_do_listy_drog(ogon_drogi->nastepny, bufor);

			if (!ogon_drogi->nastepny)
				return PROGRAM_NIE;

			ogon_drogi = ogon_drogi->nastepny;
		}
	}

	fclose(wejscie);

	wejscie = fopen(plik_trasy, "r");

	if (!wejscie)
	{
		if (plik_trasy[strlen(plik_trasy) - 4] == '.')
		{
			plik_trasy[strlen(plik_trasy) - 3] = 't';
			plik_trasy[strlen(plik_trasy) - 2] = 'x';
			plik_trasy[strlen(plik_trasy) - 1] = 't';
		}
		else
			strcat(plik_trasy, ".txt");

		wejscie = fopen(plik_trasy, "r");

		if (!wejscie)
		{
			printf("Plik z odleglosciami nie zostal otwarty!\n");
			return PROGRAM_NIE;
		}
	}

	// odczytywanie tras

	lista_trasy* ogon_trasy;

	while (!feof(wejscie))
	{
		fgets(bufor, ROZMIAR_BUFORA, wejscie);

		if (!(*glowa_trasy))
		{
			*glowa_trasy = dodaj_do_listy_tras(*glowa_trasy, bufor);
			ogon_trasy = *glowa_trasy;
		}
		else
		{
			ogon_trasy->nastepny = dodaj_do_listy_tras(ogon_trasy->nastepny, bufor);
			ogon_trasy = ogon_trasy->nastepny;
		}
	}

	fclose(wejscie);

	return PROGRAM_OK;
}

// tworzenie grafu

int tworz_graf(lista_drogi** glowa_drogi, graf* graf_caly)
{
	char* miasto1;
	char* miasto2;

	lista_drogi* pomoc_drogi;
	pomoc_drogi = *glowa_drogi;

	graf_skad* glowa_grafu;
	glowa_grafu = NULL;

	graf_skad* ogon_grafu;
	ogon_grafu = NULL;

	graf_skad* pomoc_graf;

	int jest1, jest2;

	graf_caly->ile_wierzcholkow = 0;

	while (pomoc_drogi)
	{
		miasto1 = pomoc_drogi->skad;
		miasto2 = pomoc_drogi->dokad;

		if (!glowa_grafu)
		{
			glowa_grafu = (graf_skad*)malloc(sizeof(graf_skad));
			glowa_grafu->skad = (char*)malloc(ROZMIAR_NAZW);
			glowa_grafu->dokad = NULL;

			graf_caly->graf_glowa = glowa_grafu;

			strncpy(glowa_grafu->skad, miasto1, strlen(miasto1) + 1);

			ogon_grafu = (graf_skad*)malloc(sizeof(graf_skad));
			ogon_grafu->nastepny = NULL;
			ogon_grafu->dokad = NULL;
			ogon_grafu->skad = (char*)malloc(ROZMIAR_NAZW);

			strncpy(ogon_grafu->skad, miasto2, strlen(miasto2) + 1);

			glowa_grafu->nastepny = ogon_grafu;

			pomoc_drogi = pomoc_drogi->nastepny;

			graf_caly->ile_wierzcholkow += 2;

			continue;
		}

		pomoc_graf = glowa_grafu;

		jest1 = 0;
		jest2 = 0;

		while (pomoc_graf)
		{
			if (!(strcmp(miasto1, pomoc_graf->skad)))
				jest1 = 1;

			if (!(strcmp(miasto2, pomoc_graf->skad)))
				jest2 = 1;

			pomoc_graf = pomoc_graf->nastepny;
		}

		if (!jest1)		// mozna utowrzyc wierzcholek z miastem 1 - jako nowy ogon
		{
			ogon_grafu->nastepny = (graf_skad*)malloc(sizeof(graf_skad));
			ogon_grafu = ogon_grafu->nastepny;
			ogon_grafu->nastepny = NULL;
			ogon_grafu->dokad = NULL;
			ogon_grafu->skad = (char*)malloc(ROZMIAR_NAZW);

			strncpy(ogon_grafu->skad, miasto1, strlen(miasto1) + 1);

			++(graf_caly->ile_wierzcholkow);
		}

		if (!jest2)
		{
			ogon_grafu->nastepny = (graf_skad*)malloc(sizeof(graf_skad));
			ogon_grafu = ogon_grafu->nastepny;
			ogon_grafu->nastepny = NULL;
			ogon_grafu->dokad = NULL;
			ogon_grafu->skad = (char*)malloc(ROZMIAR_NAZW);

			strncpy(ogon_grafu->skad, miasto2, strlen(miasto2) + 1);

			++(graf_caly->ile_wierzcholkow);
		}

		pomoc_drogi = pomoc_drogi->nastepny;
	}

	// dodawanie podwieszonych list celow

	pomoc_drogi = *glowa_drogi;

	graf_skad* znaleziony_element;
	znaleziony_element = NULL;

	while (pomoc_drogi)
	{
		miasto1 = pomoc_drogi->skad;
		miasto2 = pomoc_drogi->dokad;

		pomoc_graf = glowa_grafu;

		while (pomoc_graf)
		{
			if (!(strcmp(miasto1, pomoc_graf->skad)))
			{
				znaleziony_element = pomoc_graf;
				break;
			}

			pomoc_graf = pomoc_graf->nastepny;
		}

		graf_dokad* koniec_celow;
		koniec_celow = NULL;

		if (!znaleziony_element)
			continue;

		if (!(znaleziony_element->dokad))
		{
			znaleziony_element->dokad = (graf_dokad*)malloc(sizeof(graf_dokad));

			koniec_celow = znaleziony_element->dokad;

			koniec_celow->nastepny = NULL;
			koniec_celow->dystans = pomoc_drogi->dystans;
			koniec_celow->cel = (char*)malloc(ROZMIAR_NAZW);

			strncpy(koniec_celow->cel, miasto2, strlen(miasto2) + 1);

			pomoc_drogi = pomoc_drogi->nastepny;
			continue;
		}

		koniec_celow = znaleziony_element->dokad;

		while (koniec_celow)
		{
			if (!(koniec_celow->nastepny))
				break;

			koniec_celow = koniec_celow->nastepny;
		}


		koniec_celow->nastepny = (graf_dokad*)malloc(sizeof(graf_dokad));

		koniec_celow = koniec_celow->nastepny;

		koniec_celow->nastepny = NULL;
		koniec_celow->dystans = pomoc_drogi->dystans;
		koniec_celow->cel = (char*)malloc(ROZMIAR_NAZW);

		strncpy(koniec_celow->cel, miasto2, strlen(miasto2) + 1);

		pomoc_drogi = pomoc_drogi->nastepny;
	}

	return PROGRAM_OK;
}

// dodawanie do stosu poprzednikow

stos_poprzednikow* daj_na_stos(stos_poprzednikow* szczyt, int poprzednik, int dystans)
{
	stos_poprzednikow* nowy_poprzednik;

	nowy_poprzednik = (stos_poprzednikow*)malloc(sizeof(stos_poprzednikow));
	nowy_poprzednik->poprzednik = poprzednik;
	nowy_poprzednik->dystans = dystans;
	nowy_poprzednik->nastepny = szczyt;
	szczyt = nowy_poprzednik;

	return szczyt;
}

// niszczenie stosu poprzednikow

stos_poprzednikow* skasuj_stos(stos_poprzednikow* szczyt)
{
	stos_poprzednikow* smiec;
	smiec = szczyt;
	szczyt = szczyt->nastepny;

	while (smiec)
	{
		free(smiec);

		smiec = szczyt;

		if (szczyt)
			szczyt = szczyt->nastepny;
	}

	szczyt = NULL;

	return szczyt;
}

// obliczanie tras - algorytm Floyda  - Warshalla

int licz_trasy(graf* graf_caly, lista_trasy* glowa_trasy, char plik_wyjscie[])
{
	char** miasta;

	miasta = (char**)malloc(graf_caly->ile_wierzcholkow * sizeof(char*));

	graf_skad* glowa_grafu;
	glowa_grafu = graf_caly->graf_glowa;

	graf_skad* pomoc_graf;
	pomoc_graf = glowa_grafu;

	graf_dokad* pomoc_cele;
	pomoc_cele = NULL;

	int wymiar = graf_caly->ile_wierzcholkow;

	int** odleglosci;
	int** poprzednicy;

	odleglosci = (int**)malloc(wymiar * sizeof(int*));
	poprzednicy = (int**)malloc(wymiar * sizeof(int*));

	// tablica z nazwami miast, alokacja pamieci, wstepne wypelnienie

	for (int i = 0; i < wymiar; ++i)
	{
		miasta[i] = (char*)malloc(strlen(pomoc_graf->skad) + 1);

		strncpy(miasta[i], pomoc_graf->skad, strlen(pomoc_graf->skad) + 1);

		pomoc_graf = pomoc_graf->nastepny;

		odleglosci[i] = (int*)malloc(wymiar * sizeof(int));
		poprzednicy[i] = (int*)malloc(wymiar * sizeof(int));

		for (int j = 0; j < wymiar; ++j)
		{
			if (i == j)
				odleglosci[i][j] = 0;
			else
				odleglosci[i][j] = INT_MAX;

			poprzednicy[i][j] = -1;
		}
	}

	pomoc_graf = glowa_grafu;
	pomoc_cele = pomoc_graf->dokad;

	// wyznaczenie poczatkowych wag polaczen

	for (int i = 0; i < wymiar; ++i)
	{
		if (pomoc_cele)
			while (pomoc_cele)
			{
				for (int j = 0; j < wymiar; ++j)
					if (!strcmp(pomoc_cele->cel, miasta[j]))
					{
						odleglosci[i][j] = pomoc_cele->dystans;
						poprzednicy[i][j] = i;
					}
				pomoc_cele = pomoc_cele->nastepny;
			}
		pomoc_graf = pomoc_graf->nastepny;

		if (pomoc_graf)
			pomoc_cele = pomoc_graf->dokad;
	}

	// wlasciwy Floyd - Warshall :D

	int odleglosc_temp;

	for (int i = 0; i < wymiar; ++i)
		for (int j = 0; j < wymiar; ++j)
			for (int k = 0; k < wymiar; ++k)
			{
				if (odleglosci[j][i] == INT_MAX || odleglosci[i][k] == INT_MAX)
					continue;

				odleglosc_temp = odleglosci[j][i] + odleglosci[i][k];

				if (odleglosci[j][k] > odleglosc_temp)
				{
					odleglosci[j][k] = odleglosc_temp;
					poprzednicy[j][k] = poprzednicy[i][k];
				}
			}

	// petla ze wszystkim - wyznaczeniem sciezek i zapisem do pliku

	FILE* pliczek;

	if (plik_wyjscie[strlen(plik_wyjscie) - 4] != '.')
		strcat(plik_wyjscie, ".txt");

	pliczek = fopen(plik_wyjscie, "w");

	lista_trasy* pomoc_trasy;
	pomoc_trasy = glowa_trasy;

	int skad, dokad, dokad_temp;

	stos_poprzednikow* szczyt_stosu = NULL;

	while (pomoc_trasy)
	{
		for (int i = 0; i < wymiar; ++i)
		{
			if (!strcmp(pomoc_trasy->skad, miasta[i]))
				skad = i;
			if (!strcmp(pomoc_trasy->dokad, miasta[i]))
				dokad = i;
		}


		if (skad == dokad)
		{
			fprintf(pliczek, "trasa: %s --> %s (0 km)\n\n", miasta[skad], miasta[dokad]);

			pomoc_trasy = pomoc_trasy->nastepny;

			continue;
		}

		if (odleglosci[skad][dokad] == INT_MAX)
		{
			fprintf(pliczek, "trasa: %s --> %s\n", miasta[skad], miasta[dokad]);
			fprintf(pliczek, "TRASA NIEMOZLIWA DO WYZNACZENIA\n\n");

			pomoc_trasy = pomoc_trasy->nastepny;

			continue;
		}

		// tworzymy stos

		dokad_temp = dokad;

		while (skad != dokad_temp)
		{
			szczyt_stosu = daj_na_stos(szczyt_stosu, poprzednicy[skad][dokad_temp], odleglosci[skad][dokad_temp]);
			dokad_temp = poprzednicy[skad][dokad_temp];
		}

		// zapis do pliku, zniszczenie stosu

		stos_poprzednikow* pomoc_stos;
		pomoc_stos = szczyt_stosu;

		int poprzedni_dystans = 0;
		int aktualny_dystans, poprzednie_miasto;

		poprzednie_miasto = skad;

		fprintf(pliczek, "trasa: %s --> %s (%d km)\n", miasta[skad], miasta[dokad], odleglosci[skad][dokad]);

		while (pomoc_stos)
		{
			aktualny_dystans = pomoc_stos->dystans - poprzedni_dystans;
			poprzedni_dystans = pomoc_stos->dystans;

			pomoc_stos = pomoc_stos->nastepny;

			if (!pomoc_stos)
			{
				fprintf(pliczek, "\t%s --> %s\t\t%d\n", miasta[poprzednie_miasto], miasta[dokad], aktualny_dystans);
				break;
			}

			fprintf(pliczek, "\t%s --> %s\t\t%d\n", miasta[poprzednie_miasto], miasta[pomoc_stos->poprzednik], aktualny_dystans);

			poprzednie_miasto = pomoc_stos->poprzednik;
		}

		fprintf(pliczek, "\n");
		szczyt_stosu = skasuj_stos(szczyt_stosu);
		pomoc_trasy = pomoc_trasy->nastepny;
	}

	fclose(pliczek);

	// nie ruszac, nie dychac, bo zwalnianie pamieci dziala!!

	for (int i = 0; i < wymiar; ++i)
	{
		free(miasta[i]);
		free(odleglosci[i]);
		free(poprzednicy[i]);
	}

	free(miasta);
	free(odleglosci);
	free(poprzednicy);

	return PROGRAM_OK;
}