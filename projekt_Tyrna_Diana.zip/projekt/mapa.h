#pragma once

#ifndef mapa
#define mapa

enum wynik
{
	PROGRAM_NIE,
	PROGRAM_OK,
	PROGRAM_POMOC
};

typedef struct lista_drogi_
{
	char* skad;
	char* dokad;
	int dystans;
	struct lista_drogi* nastepny;
} lista_drogi;

typedef struct lista_trasy_
{
	char* skad;
	char* dokad;
	struct lista_trasy* nastepny;
} lista_trasy;

typedef struct graf_
{
	struct graf_dokad* graf_glowa;
	int ile_wierzcholkow;
} graf;

typedef struct graf_dokad_
{
	char* cel;
	int dystans;
	struct graf_dokad* nastepny;
} graf_dokad;

typedef struct graf_skad_
{
	char* skad;
	struct graf_skad* nastepny;
	struct graf_dokad* dokad;
} graf_skad;

typedef struct stos_poprzednikow_
{
	int poprzednik;
	int dystans;
	struct stos_poprzednikow* nastepny;
} stos_poprzednikow;

// odczytywanie parametrow

int odczytaj_parametry(int, char*[], char[], char[], char[]);

// pomocnicza funkcja usprawniajaca dodawanie do listy odczytanych drog

lista_drogi* dodaj_do_listy_drog(lista_drogi*, char*);

// pomocnicza funkcja usprawniajaca dodawanie do listy odczytanych tras

lista_trasy* dodaj_do_listy_tras(lista_trasy*, char*);

// funkcja kasujaca liste tras

void skasuj_drogi(lista_drogi*);

// funkcja kasujaca liste drog

void skasuj_trasy(lista_trasy*);

// funkcja kasujaca graf

void skasuj_graf(graf*);

// odczytwanie plikow

int odczytaj_pliki(char[], char[], lista_drogi**, lista_trasy**);

// tworzenie grafu

int tworz_graf(lista_drogi**, graf*);

// dodawanie do stosu poprzednikow

stos_poprzednikow* daj_na_stos(stos_poprzednikow*, int, int);

// niszczenie stosu poprzednikow

stos_poprzednikow* skasuj_stos(stos_poprzednikow*);

// obliczanie tras - algorytm Floyda  - Warshalla

int licz_trasy(graf*, lista_trasy*, char[]);

#endif