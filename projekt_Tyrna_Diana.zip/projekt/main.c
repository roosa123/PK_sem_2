/*projekt o mapie*/

#define _CRT_SECURE_NO_WARNINGS

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"mapa.h"

#define ROZMIAR_NAZW 32
#define POMOC "Program sluzy do obliczania najkrotszych tras miedzy wskazanymi miastami.\nPo rzelaczniku -d nalezy podac nazwe pliku ze spisem drog.\nPo przelaczniku -t nalezy podac plik z trasami do wyznaczenia.\nPo przelaczniku -o nalezy podac nazwe pliku wyjsciowego.\n"


// main

int main(int argc, char* argv[])
{
	char nazwa_drogi[ROZMIAR_NAZW];
	char nazwa_trasy[ROZMIAR_NAZW];
	char nazwa_wyjscie[ROZMIAR_NAZW];

	int odczyt;

	odczyt = odczytaj_parametry(argc, argv, nazwa_wyjscie, nazwa_drogi, nazwa_trasy);

	switch (odczyt)
	{
	case PROGRAM_NIE:		printf("Zle uruchomiono.\n");
							printf(POMOC);
							system("pause");
							return 0;

	case PROGRAM_POMOC:		printf(POMOC);
							system("pause");
							return 0;

	case PROGRAM_OK:		break;

	default:				printf("Nieznana akcja.\n");
							printf(POMOC);
							system("pause");
							return 0;
	}

	lista_drogi* glowa_drogi;
	lista_trasy* glowa_trasy;

	glowa_drogi = NULL;
	glowa_trasy = NULL;

	odczyt = odczytaj_pliki(nazwa_drogi, nazwa_trasy, &glowa_drogi, &glowa_trasy);

	if (odczyt == PROGRAM_NIE)
	{
		printf("Cos poszlo nie tak z odczytem.\n");
		printf(POMOC);
		system("pause");
		return 0;
	}

	graf glowagrafu;

	tworz_graf(&glowa_drogi, &glowagrafu);

	skasuj_drogi(glowa_drogi);

	licz_trasy(&glowagrafu, glowa_trasy, nazwa_wyjscie);

	skasuj_trasy(glowa_trasy);
	skasuj_graf(&glowagrafu);

	system("pause");
	return 0;
}